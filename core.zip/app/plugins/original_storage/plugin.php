<?php

class DDI_StoreOriginals extends KokenPlugin implements KokenOriginalStore {

	function send($localFile)
	{
		return false;
	}

}