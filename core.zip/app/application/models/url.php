<?php

class Url extends DataMapper {}

/* End of file url.php */
/* Location: ./application/models/url.php */